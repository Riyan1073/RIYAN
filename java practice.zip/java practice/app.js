alert("Thanks for your input!") // code alternative 
window.alert("Thanks for your input!")
var name = "Riyan"  //string I could have called it myName, xyz, lol, or something else.
printf = "name"
 var originalNum = 23;
 var numToBeAdded = 7;
 var newNum = originalNum + numToBeAdded;
 console.log(newNum)
 var num = 10;
 var anotherNum = 1;
 var popularNumber = num + anotherNum;
 console.log(popularNumber)
 var num = 1;
 var newNum = ++num;
console.log(newNum)
 var num = 1;
 var newNum = --num;
 console.log(newNum)
 var resultOfComputation = (2 * 4) * 4 + 2;
 console.log(resultOfComputation )
 var resultOfComputation = (2 * 4) * (4 + 2);
 console.log(resultOfComputation )
 

